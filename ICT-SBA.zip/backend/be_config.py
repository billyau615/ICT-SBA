#!/usr/bin/env python3
CONFIG = {
    "database": "users.db"
}

def GET_DATABASE():
    return CONFIG["database"]