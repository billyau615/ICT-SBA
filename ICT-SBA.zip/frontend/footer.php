<footer>
        <hr id="footerhr">
        <div id="footer">
            <p id="copyright">&copy; <?php echo date("Y"); ?> Sky Airlines. All rights reserved.</p>
            <a id ="tositemap" href="sitemap.php">Site Map</a>  
        </div>
    </footer>